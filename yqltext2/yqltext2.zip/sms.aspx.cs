﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yqltext2
{
    public partial class sms : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string From = Request["From"];
            string To = Request["To"];
            string Body = Request["Body"];

        if (Body == "mark")
            {
                Response.Write("hey mark");
            }

        }
    }
}